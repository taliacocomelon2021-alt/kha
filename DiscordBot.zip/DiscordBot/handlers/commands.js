const { PermissionsBitField } = require('discord.js');
const logger = require('../utils/logger');
const config = require('../config/config');

class CommandHandler {
  static async registerCommands(guild) {
    try {
      const commands = [
        {
          name: 'send-ticket-panel',
          description: 'يرسل لوحة التذاكر'
        },
        {
          name: 'ticket-stats',
          description: 'يعرض إحصائيات نظام التذاكر'
        },
        {
          name: 'health-check',
          description: 'فحص حالة البوت'
        }
      ];

      await guild.commands.set(commands);
      logger.info(`Registered ${commands.length} commands for guild ${guild.name}`);
    } catch (error) {
      logger.error('Failed to register commands:', error);
      throw error;
    }
  }

  static async handleCommand(interaction) {
    try {
      const { commandName, member } = interaction;

      // Check if user has admin permissions for certain commands
      const adminCommands = ['send-ticket-panel', 'health-check'];
      if (adminCommands.includes(commandName)) {
        if (!member.permissions.has(PermissionsBitField.Flags.Administrator) && 
            !member.roles.cache.has(config.ADMIN_ROLE_ID)) {
          return interaction.reply({
            content: '❌ عذراً، هذا الأمر للإدارة فقط',
            ephemeral: true
          });
        }
      }

      // Import and execute command
      const command = require(`../commands/${commandName}`);
      await command.execute(interaction);
      
      logger.info(`Command executed: ${commandName} by ${interaction.user.tag}`);
    } catch (error) {
      logger.error(`Error executing command ${interaction.commandName}:`, error);
      
      const errorMessage = '❌ حدث خطأ أثناء تنفيذ الأمر. يرجى المحاولة لاحقاً.';
      
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: errorMessage, ephemeral: true });
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true });
      }
    }
  }
}

module.exports = CommandHandler;
