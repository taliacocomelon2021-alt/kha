const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const TicketHandler = require('./tickets');
const logger = require('../utils/logger');
const storage = require('../utils/storage');
const config = require('../config/config');
const EmbedManager = require('../utils/embeds');
const cooldownManager = require('../middleware/cooldown');

class InteractionHandler {
  static async handleSelectMenu(interaction) {
    if (interaction.customId !== 'select_support') return;

    try {
      const value = interaction.values[0];
      const userId = interaction.user.id;

      // Check cooldown
      if (cooldownManager.isOnCooldown(userId, 'ticket_creation')) {
        const remaining = cooldownManager.getRemainingTime(userId, 'ticket_creation');
        return interaction.reply({
          content: `❌ يجب الانتظار ${Math.ceil(remaining / 1000)} ثانية قبل إنشاء تذكرة جديدة`,
          ephemeral: true
        });
      }

      // Check user tickets
      const userTickets = storage.getUserTickets(userId);
      if (userTickets.length >= config.LIMITS.MAX_TICKETS_PER_USER) {
        return interaction.reply({
          content: `❌ لديك ${userTickets.length} تذاكر مفتوحة. الحد الأقصى هو ${config.LIMITS.MAX_TICKETS_PER_USER} تذاكر`,
          ephemeral: true
        });
      }

      // Set cooldown
      cooldownManager.setCooldown(userId, 'ticket_creation', config.LIMITS.COOLDOWN_TIME);

      // Show game support form
      if (value === 'games_support') {
        const modal = new ModalBuilder()
          .setCustomId('game_support_modal')
          .setTitle('🎮 دعم الألعاب');

        const gameInput = new TextInputBuilder()
          .setCustomId('game')
          .setLabel('ما هي اللعبة؟')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100);

        const userInput = new TextInputBuilder()
          .setCustomId('reported_user')
          .setLabel('من هو الشخص الذي تواجه مشكلة معه؟')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100);

        const issueInput = new TextInputBuilder()
          .setCustomId('problem')
          .setLabel('ما هي المشكلة؟')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000);

        const needOwnerInput = new TextInputBuilder()
          .setCustomId('need_owner')
          .setLabel('هل تحتاج تدخل صاحب السيرفر؟ (نعم / لا)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(10);

        modal.addComponents(
          new ActionRowBuilder().addComponents(gameInput),
          new ActionRowBuilder().addComponents(userInput),
          new ActionRowBuilder().addComponents(issueInput),
          new ActionRowBuilder().addComponents(needOwnerInput)
        );

        await interaction.showModal(modal);
        return;
      }

      // Show problem report form for basic tickets
      if (value === 'discord_support' || value === 'report_issue') {
        const modal = new ModalBuilder()
          .setCustomId(`${value}_problem_modal`)
          .setTitle(value === 'discord_support' ? '💠 دعم ديسكورد' : '⚠️ الإبلاغ عن مشكلة');

        const problemInput = new TextInputBuilder()
          .setCustomId('problem_description')
          .setLabel('ما هي المشكلة؟')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000);

        const personInput = new TextInputBuilder()
          .setCustomId('person_causing_harm')
          .setLabel('لو حد ضرك، اكتب اسمه هنا (اختياري)')
          .setStyle(TextInputStyle.Short)
          .setRequired(false)
          .setMaxLength(100);

        modal.addComponents(
          new ActionRowBuilder().addComponents(problemInput),
          new ActionRowBuilder().addComponents(personInput)
        );

        await interaction.showModal(modal);
        return;
      }

      // Show admin application form
      if (value === 'admin_application') {
        const modal = new ModalBuilder()
          .setCustomId('admin_application_modal')
          .setTitle('👑 تقديم إداري');

        const nameInput = new TextInputBuilder()
          .setCustomId('name')
          .setLabel('ما هو اسمك؟')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(50);

        const ageInput = new TextInputBuilder()
          .setCustomId('age')
          .setLabel('كم عمرك؟')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(3);

        const countryInput = new TextInputBuilder()
          .setCustomId('country')
          .setLabel('ما هو بلدك؟')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(50);

        const experienceInput = new TextInputBuilder()
          .setCustomId('experience')
          .setLabel('ما هي خبرتك في الإدارة؟')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000);

        modal.addComponents(
          new ActionRowBuilder().addComponents(nameInput),
          new ActionRowBuilder().addComponents(ageInput),
          new ActionRowBuilder().addComponents(countryInput),
          new ActionRowBuilder().addComponents(experienceInput)
        );

        await interaction.showModal(modal);
        return;
      }

      // Create regular ticket
      await TicketHandler.createTicket(interaction, value);
      
    } catch (error) {
      logger.error('Error handling select menu:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء إنشاء التذكرة. يرجى المحاولة لاحقاً.',
        ephemeral: true
      });
    }
  }

  static async handleModal(interaction) {
    if (interaction.customId === 'game_support_modal') {
      await this.handleGameSupportModal(interaction);
    } else if (interaction.customId === 'admin_application_modal') {
      await this.handleAdminApplicationModal(interaction);
    } else if (interaction.customId === 'discord_support_problem_modal') {
      await this.handleProblemModal(interaction, 'discord_support');
    } else if (interaction.customId === 'report_issue_problem_modal') {
      await this.handleProblemModal(interaction, 'report_issue');
    } else if (interaction.customId === 'rating_modal') {
      await this.handleRatingModal(interaction);
    }
  }

  static async handleGameSupportModal(interaction) {

    try {
      const game = interaction.fields.getTextInputValue('game').trim();
      const reported = interaction.fields.getTextInputValue('reported_user').trim();
      const problem = interaction.fields.getTextInputValue('problem').trim();
      const needOwner = interaction.fields.getTextInputValue('need_owner').trim();

      // Validate inputs
      if (!game || !reported || !problem || !needOwner) {
        return interaction.reply({
          content: '❌ يرجى ملء جميع الحقول المطلوبة',
          ephemeral: true
        });
      }

      const needOwnerBool = needOwner.toLowerCase().includes('نعم') || 
                           needOwner.toLowerCase().includes('yes');

      const gameData = {
        game,
        reported,
        problem,
        needOwner: needOwnerBool
      };

      await TicketHandler.createGameTicket(interaction, gameData);
      
    } catch (error) {
      logger.error('Error handling game support modal:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء إنشاء تذكرة دعم الألعاب. يرجى المحاولة لاحقاً.',
        ephemeral: true
      });
    }
  }

  static async handleAdminApplicationModal(interaction) {
    try {
      const name = interaction.fields.getTextInputValue('name').trim();
      const age = interaction.fields.getTextInputValue('age').trim();
      const country = interaction.fields.getTextInputValue('country').trim();
      const experience = interaction.fields.getTextInputValue('experience').trim();

      // Validate inputs
      if (!name || !age || !country || !experience) {
        return interaction.reply({
          content: '❌ يرجى ملء جميع الحقول المطلوبة',
          ephemeral: true
        });
      }

      // Validate age is a number
      if (isNaN(age) || parseInt(age) < 13 || parseInt(age) > 99) {
        return interaction.reply({
          content: '❌ يرجى إدخال عمر صحيح (13-99 سنة)',
          ephemeral: true
        });
      }

      const adminData = {
        name,
        age,
        country,
        experience
      };

      await TicketHandler.createAdminApplicationTicket(interaction, adminData);
      
    } catch (error) {
      logger.error('Error handling admin application modal:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء إنشاء تذكرة التقديم الإداري. يرجى المحاولة لاحقاً.',
        ephemeral: true
      });
    }
  }

  static async handleButton(interaction) {
    try {
      const { customId } = interaction;
      const ticket = storage.getTicket(interaction.channel.id);

      if (!ticket) {
        return interaction.reply({
          content: '❌ لم يتم العثور على بيانات هذه التذكرة',
          ephemeral: true
        });
      }

      switch (customId) {
        case 'claim_ticket':
          await TicketHandler.claimTicket(interaction, ticket);
          break;

        case 'rate_ticket':
          await TicketHandler.showRatingModal(interaction);
          break;

        case 'close_ticket':
          await TicketHandler.initiateClose(interaction);
          break;

        case 'confirm_close':
          await TicketHandler.confirmClose(interaction);
          break;

        case 'cancel_close':
          await interaction.update({
            content: '❌ تم إلغاء عملية إغلاق التذكرة',
            components: []
          });
          break;

        case 'delete_ticket':
          await TicketHandler.deleteTicket(interaction);
          break;

        default:
          // Handle rating buttons
          if (customId.startsWith('rate_')) {
            const rating = parseInt(customId.split('_')[1]);
            await TicketHandler.handleRating(interaction, ticket, rating);
          }
          break;
      }
      
    } catch (error) {
      logger.error('Error handling button interaction:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء معالجة طلبك. يرجى المحاولة لاحقاً.',
        ephemeral: true
      });
    }
  }

  static async handleProblemModal(interaction, ticketType) {
    try {
      const problemDescription = interaction.fields.getTextInputValue('problem_description').trim();
      const personCausingHarm = interaction.fields.getTextInputValue('person_causing_harm').trim();

      // Validate inputs
      if (!problemDescription) {
        return interaction.reply({
          content: '❌ يرجى كتابة وصف للمشكلة',
          ephemeral: true
        });
      }

      const problemData = {
        problemDescription,
        personCausingHarm: personCausingHarm || 'لا يوجد'
      };

      await TicketHandler.createProblemTicket(interaction, ticketType, problemData);
      
    } catch (error) {
      logger.error('Error handling problem modal:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء إنشاء التذكرة. يرجى المحاولة لاحقاً.',
        ephemeral: true
      });
    }
  }

  static async handleRatingModal(interaction) {
    try {
      const rating = parseInt(interaction.fields.getTextInputValue('rating_value').trim());
      const comment = interaction.fields.getTextInputValue('rating_comment').trim();

      // Validate rating
      if (isNaN(rating) || rating < 1 || rating > 5) {
        return interaction.reply({
          content: '❌ يرجى إدخال تقييم صحيح من 1 إلى 5',
          ephemeral: true
        });
      }

      const ratingData = {
        rating,
        comment: comment || 'لا يوجد تعليق',
        ratedBy: interaction.user.id
      };

      await TicketHandler.saveRating(interaction, ratingData);
      
    } catch (error) {
      logger.error('Error handling rating modal:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء حفظ التقييم. يرجى المحاولة لاحقاً.',
        ephemeral: true
      });
    }
  }
}

module.exports = InteractionHandler;
