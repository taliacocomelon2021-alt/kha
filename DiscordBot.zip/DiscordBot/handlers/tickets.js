const { ChannelType, PermissionsBitField, EmbedBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const storage = require('../utils/storage');
const EmbedManager = require('../utils/embeds');
const config = require('../config/config');
const logger = require('../utils/logger');

class TicketHandler {
  static async createTicket(interaction, type) {
    try {
      const typeInfo = config.TICKET_TYPES.find(t => t.id === type);
      const channelName = `${config.EMOJIS.TICKET}・${typeInfo.prefix}-${interaction.user.username}`;
      
      const channel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.CATEGORY_ID,
        permissionOverwrites: [
          { 
            id: interaction.guild.id, 
            deny: [PermissionsBitField.Flags.ViewChannel] 
          },
          { 
            id: interaction.user.id, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks
            ]
          },
          { 
            id: config.ADMIN_ROLE_ID, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks,
              PermissionsBitField.Flags.ManageMessages
            ]
          }
        ]
      });

      // Save ticket data
      const ticketData = {
        channelId: channel.id,
        userId: interaction.user.id,
        type: type,
        createdAt: Date.now(),
        status: 'open'
      };

      storage.setTicket(channel.id, ticketData);
      storage.incrementTotalTickets();

      // Send ticket embed
      const embed = EmbedManager.ticketEmbed(type, interaction.user, ticketData);
      const controls = EmbedManager.ticketControls();

      await channel.send({
        content: `${interaction.user} | <@&${config.ADMIN_ROLE_ID}>`,
        embeds: [embed],
        components: [controls]
      });

      await interaction.reply({
        content: `✅ تم فتح تذكرتك في ${channel}`,
        ephemeral: true
      });

      logger.info(`Ticket created: ${type} by ${interaction.user.tag} in ${channel.name}`);
      
    } catch (error) {
      logger.error('Error creating ticket:', error);
      throw error;
    }
  }

  static async createGameTicket(interaction, gameData) {
    try {
      const channelName = `${config.EMOJIS.GAMES}・game-${interaction.user.username}`;
      
      const channel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.CATEGORY_ID,
        permissionOverwrites: [
          { 
            id: interaction.guild.id, 
            deny: [PermissionsBitField.Flags.ViewChannel] 
          },
          { 
            id: interaction.user.id, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks
            ]
          },
          { 
            id: config.ADMIN_ROLE_ID, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks,
              PermissionsBitField.Flags.ManageMessages
            ]
          }
        ]
      });

      // Save ticket data
      const ticketData = {
        channelId: channel.id,
        userId: interaction.user.id,
        type: 'games_support',
        ...gameData,
        createdAt: Date.now(),
        status: 'open'
      };

      storage.setTicket(channel.id, ticketData);
      storage.incrementTotalTickets();

      // Send ticket embed
      const embed = EmbedManager.ticketEmbed('games_support', interaction.user, ticketData);
      const controls = EmbedManager.ticketControls();

      const mentions = gameData.needOwner 
        ? `${interaction.user} | <@&${config.ADMIN_ROLE_ID}> | <@${config.OWNER_ID}>`
        : `${interaction.user} | <@&${config.ADMIN_ROLE_ID}>`;

      await channel.send({
        content: mentions,
        embeds: [embed],
        components: [controls]
      });

      await interaction.reply({
        content: `✅ تم فتح تذكرة دعم الألعاب في ${channel}`,
        ephemeral: true
      });

      logger.info(`Game ticket created by ${interaction.user.tag} in ${channel.name}`);
      
    } catch (error) {
      logger.error('Error creating game ticket:', error);
      throw error;
    }
  }

  static async claimTicket(interaction, ticket) {
    try {
      if (!interaction.member.roles.cache.has(config.ADMIN_ROLE_ID)) {
        return interaction.reply({
          content: '❌ عذراً، هذا الزر للإدارة فقط',
          ephemeral: true
        });
      }

      if (ticket?.claimed) {
        return interaction.reply({
          content: `❌ هذه التذكرة مستلمة بالفعل من قبل <@${ticket.claimedBy}>`,
          ephemeral: true
        });
      }

      // Update ticket data
      ticket.claimed = true;
      ticket.claimedBy = interaction.user.id;
      ticket.claimedAt = Date.now();
      storage.setTicket(interaction.channel.id, ticket);

      // Update message
      const message = (await interaction.channel.messages.fetch()).first();
      const oldEmbed = message.embeds[0];
      
      const newEmbed = EmbedBuilder.from(oldEmbed)
        .addFields({
          name: '👤 حالة التذكرة',
          value: `تم استلام التذكرة بواسطة ${interaction.user}`,
          inline: false
        });

      const controls = EmbedManager.ticketControls(true, interaction.user.id);

      await message.edit({
        embeds: [newEmbed],
        components: [controls]
      });

      await interaction.reply(`✅ تم استلام التذكرة بواسطة ${interaction.user}`);
      
      logger.info(`Ticket claimed by ${interaction.user.tag} in ${interaction.channel.name}`);
      
    } catch (error) {
      logger.error('Error claiming ticket:', error);
      throw error;
    }
  }

  static async initiateClose(interaction) {
    try {
      const confirmRow = EmbedManager.closeConfirmation();
      await interaction.reply({
        content: 'هل أنت متأكد أنك تريد إغلاق التذكرة؟',
        components: [confirmRow],
        ephemeral: true
      });
    } catch (error) {
      logger.error('Error initiating ticket close:', error);
      throw error;
    }
  }

  static async closeTicket(interaction, ticket) {
    try {
      await interaction.update({
        content: '🚨 سيتم إغلاق التذكرة خلال 5 ثوان...',
        components: []
      });

      // Create transcript
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      const transcript = messages.reverse().map(m => {
        const time = new Date(m.createdTimestamp).toLocaleString('ar-SA');
        const content = m.content || '[رسالة فارغة أو مرفق]';
        return `[${time}] ${m.author.tag}: ${content}`;
      }).join('\n');

      const transcriptFile = new AttachmentBuilder(
        Buffer.from(transcript, 'utf8'),
        { name: `transcript-${interaction.channel.name}.txt` }
      );

      // Calculate duration
      const duration = Date.now() - ticket.createdAt;
      const hours = Math.floor(duration / (1000 * 60 * 60));
      const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

      const transcriptEmbed = EmbedManager.transcriptEmbed({
        channelName: interaction.channel.name,
        creator: `<@${ticket.userId}>`,
        claimer: ticket.claimed ? `<@${ticket.claimedBy}>` : null,
        rating: ticket.rating,
        createdAt: new Date(ticket.createdAt).toLocaleString('ar-SA'),
        closedAt: new Date().toLocaleString('ar-SA'),
        duration: `${hours}h ${minutes}m`
      });

      // Send transcript
      try {
        const transcriptChannel = await interaction.client.channels.fetch(config.TRANSCRIPT_CHANNEL_ID);
        await transcriptChannel.send({
          embeds: [transcriptEmbed],
          files: [transcriptFile]
        });
      } catch (error) {
        logger.error('Failed to send transcript:', error);
      }

      // Show rating system if ticket was claimed
      if (ticket.claimed && ticket.claimedBy) {
        const ratingEmbed = EmbedManager.ratingEmbed(ticket.channelId, `<@${ticket.claimedBy}>`);
        
        try {
          const user = await interaction.client.users.fetch(ticket.userId);
          await user.send(ratingEmbed);
        } catch (error) {
          logger.warn('Could not send rating DM to user:', error);
        }
      }

      // Update stats and delete
      storage.incrementClosedTickets();
      storage.deleteTicket(interaction.channel.id);

      // Delete channel
      setTimeout(() => {
        interaction.channel.delete().catch(error => {
          logger.error('Failed to delete ticket channel:', error);
        });
      }, 5000);

      logger.info(`Ticket closed: ${interaction.channel.name} by ${interaction.user.tag}`);
      
    } catch (error) {
      logger.error('Error closing ticket:', error);
      throw error;
    }
  }

  static async handleRating(interaction, ticket, rating) {
    try {
      if (interaction.user.id !== ticket.userId) {
        return interaction.reply({
          content: '❌ يمكنك تقييم تذاكرك فقط',
          ephemeral: true
        });
      }

      // Save rating
      const ratingData = {
        rating: rating,
        staffId: ticket.claimedBy,
        userId: ticket.userId,
        ticketType: ticket.type,
        staffTag: interaction.guild.members.cache.get(ticket.claimedBy)?.user.tag || 'Unknown',
        userTag: interaction.user.tag,
        ticketId: ticket.channelId,
        timestamp: Date.now()
      };

      storage.addRating(ticket.channelId, ratingData);

      // Update ticket with rating
      ticket.rating = rating;
      storage.setTicket(ticket.channelId, ticket);

      // Send rating to rating channel
      try {
        const ratingChannel = await interaction.client.channels.fetch(config.RATING_CHANNEL_ID);
        const ratingEmbed = new EmbedBuilder()
          .setColor(config.COLORS.SUCCESS)
          .setTitle(`${config.EMOJIS.STAR} تقييم جديد`)
          .setDescription(`
            **المستخدم:** ${interaction.user}
            **المسؤول:** <@${ticket.claimedBy}>
            **التقييم:** ${'⭐'.repeat(rating)} (${rating}/5)
            **نوع التذكرة:** ${config.TICKET_TYPES.find(t => t.id === ticket.type)?.label || ticket.type}
          `)
          .setTimestamp();

        await ratingChannel.send({ embeds: [ratingEmbed] });
      } catch (error) {
        logger.error('Failed to send rating to channel:', error);
      }

      await interaction.update({
        content: `✅ شكراً لك! تم تسجيل تقييمك: ${'⭐'.repeat(rating)}`,
        components: []
      });

      logger.info(`Rating submitted: ${rating}/5 by ${interaction.user.tag} for ticket ${ticket.channelId}`);
      
    } catch (error) {
      logger.error('Error handling rating:', error);
      throw error;
    }
  }

  static async createAdminApplicationTicket(interaction, adminData) {
    try {
      const channelName = `👑・admin-${interaction.user.username}`;
      
      const channel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.CATEGORY_ID,
        permissionOverwrites: [
          { 
            id: interaction.guild.id, 
            deny: [PermissionsBitField.Flags.ViewChannel] 
          },
          { 
            id: interaction.user.id, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks
            ]
          },
          { 
            id: config.ADMIN_ROLE_ID, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks,
              PermissionsBitField.Flags.ManageMessages
            ]
          }
        ]
      });

      // Save ticket data
      const ticketData = {
        channelId: channel.id,
        userId: interaction.user.id,
        type: 'admin_application',
        ...adminData,
        createdAt: Date.now(),
        status: 'open'
      };

      storage.setTicket(channel.id, ticketData);
      storage.incrementTotalTickets();

      // Send ticket embed
      const embed = EmbedManager.ticketEmbed('admin_application', interaction.user, ticketData);
      const controls = EmbedManager.ticketControls();

      // Mention owner for admin applications
      const mentions = `${interaction.user} | <@&${config.ADMIN_ROLE_ID}> | <@${config.OWNER_ID}>`;

      await channel.send({
        content: mentions,
        embeds: [embed],
        components: [controls]
      });

      await interaction.reply({
        content: `✅ تم إرسال طلب التقديم الإداري في ${channel}`,
        ephemeral: true
      });

      logger.info(`Admin application ticket created by ${interaction.user.tag} in ${channel.name}`);
      
    } catch (error) {
      logger.error('Error creating admin application ticket:', error);
      throw error;
    }
  }

  static async createProblemTicket(interaction, ticketType, problemData) {
    try {
      const typeInfo = config.TICKET_TYPES.find(t => t.id === ticketType);
      const channelName = `${typeInfo.emoji}・${typeInfo.prefix}-${interaction.user.username}`;
      
      const channel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: config.CATEGORY_ID,
        permissionOverwrites: [
          { 
            id: interaction.guild.id, 
            deny: [PermissionsBitField.Flags.ViewChannel] 
          },
          { 
            id: interaction.user.id, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks
            ]
          },
          { 
            id: config.ADMIN_ROLE_ID, 
            allow: [
              PermissionsBitField.Flags.ViewChannel,
              PermissionsBitField.Flags.SendMessages,
              PermissionsBitField.Flags.AttachFiles,
              PermissionsBitField.Flags.EmbedLinks,
              PermissionsBitField.Flags.ManageMessages
            ]
          }
        ]
      });

      // Save ticket data
      const ticketData = {
        channelId: channel.id,
        userId: interaction.user.id,
        type: ticketType,
        ...problemData,
        createdAt: Date.now(),
        status: 'open'
      };

      storage.setTicket(channel.id, ticketData);
      storage.incrementTotalTickets();

      // Send ticket embed
      const embed = EmbedManager.ticketEmbed(ticketType, interaction.user, ticketData);
      const controls = EmbedManager.ticketControls(false, null, ticketData);

      await channel.send({
        content: `${interaction.user} | <@&${config.ADMIN_ROLE_ID}>`,
        embeds: [embed],
        components: [controls]
      });

      await interaction.reply({
        content: `✅ تم إنشاء تذكرة الدعم في ${channel}`,
        ephemeral: true
      });

      logger.info(`Problem ticket created: ${ticketType} by ${interaction.user.tag} in ${channel.name}`);
      
    } catch (error) {
      logger.error('Error creating problem ticket:', error);
      throw error;
    }
  }

  static async sendDMSummary(user, ticketData, rating = null, staffMember = null) {
    try {
      const typeInfo = config.TICKET_TYPES.find(t => t.id === ticketData.type);
      
      const embed = new EmbedBuilder()
        .setColor(config.COLORS.SUCCESS)
        .setTitle(`${config.EMOJIS.TICKET} ملخص التذكرة`)
        .setThumbnail(config.SERVER_ICON)
        .setDescription(`
          \`\`\`
          ╔══════════════════════════════════════╗
          ║              ملخص التذكرة النهائي           ║
          ╚══════════════════════════════════════╝
          \`\`\`
          
          **🏷️ نوع التذكرة:** ${typeInfo?.label || 'غير محدد'}
          **🕐 تاريخ الإنشاء:** <t:${Math.floor(ticketData.createdAt / 1000)}:F>
          **🕐 تاريخ الإغلاق:** <t:${Math.floor(Date.now() / 1000)}:F>
          **👨‍💼 الإداري المسؤول:** ${staffMember ? `<@${staffMember}>` : 'لا يوجد'}
          **⭐ التقييم:** ${rating ? `${rating}/5 نجوم` : 'لم يتم التقييم'}
          
          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        `)
        .setFooter({ 
          text: `${config.SERVER_NAME} • شكراً لاستخدام خدماتنا`, 
          iconURL: config.SERVER_ICON 
        })
        .setTimestamp();

      await user.send({ embeds: [embed] });
      logger.info(`DM summary sent to ${user.tag}`);
      
    } catch (error) {
      logger.error('Error sending DM summary:', error);
    }
  }

  static async confirmClose(interaction) {
    try {
      const ticketData = storage.getTicket(interaction.channel.id);
      
      if (!ticketData) {
        return interaction.reply({
          content: '❌ لم يتم العثور على بيانات التذكرة.',
          ephemeral: true
        });
      }

      // Generate transcript
      await this.generateTranscript(interaction.channel, ticketData);
      
      // Mark as closed
      ticketData.status = 'closed';
      ticketData.closedAt = Date.now();
      ticketData.closedBy = interaction.user.id;
      
      storage.setTicket(interaction.channel.id, ticketData);
      storage.incrementClosedTickets();

      // Send DM summary to ticket owner
      const user = await interaction.guild.members.fetch(ticketData.userId);
      await this.sendDMSummary(user.user, ticketData, ticketData.rating, ticketData.claimedBy);

      // Create delete button for admins
      const deleteButton = new ButtonBuilder()
        .setCustomId('delete_ticket')
        .setLabel('حذف القناة')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🗑️');

      const deleteRow = new ActionRowBuilder().addComponents(deleteButton);
      
      await interaction.update({
        content: `✅ **تم إغلاق التذكرة بواسطة ${interaction.user}**\n\n📋 تم إرسال ملخص التذكرة للعضو في رسالة خاصة\n📄 تم حفظ النسخة في قناة الأرشيف\n\n**الإداريون يمكنهم حذف القناة الآن:**`,
        components: [deleteRow],
        embeds: []
      });

      logger.info(`Ticket closed: ${interaction.channel.name} by ${interaction.user.tag}`);
      
    } catch (error) {
      logger.error('Error confirming close:', error);
      throw error;
    }
  }

  static async deleteTicket(interaction) {
    try {
      // Check if user is admin
      if (!interaction.member.roles.cache.has(config.ADMIN_ROLE_ID)) {
        return interaction.reply({
          content: '❌ ليس لديك صلاحية لحذف القناة.',
          ephemeral: true
        });
      }

      await interaction.reply({
        content: '✅ سيتم حذف القناة خلال 3 ثوانٍ...',
        ephemeral: false
      });

      setTimeout(async () => {
        try {
          await interaction.channel.delete();
        } catch (error) {
          logger.error('Error deleting channel:', error);
        }
      }, 3000);

      logger.info(`Ticket deleted: ${interaction.channel.name} by ${interaction.user.tag}`);
      
    } catch (error) {
      logger.error('Error deleting ticket:', error);
      throw error;
    }
  }

  static async showRatingModal(interaction) {
    try {
      const ticketData = storage.getTicket(interaction.channel.id);
      
      if (!ticketData) {
        return interaction.reply({
          content: '❌ لم يتم العثور على بيانات التذكرة.',
          ephemeral: true
        });
      }

      // Show current rating if exists
      let currentRatingText = '';
      if (ticketData.rating) {
        const ratedBy = await interaction.guild.members.fetch(ticketData.ratedBy);
        currentRatingText = `\n\n**التقييم الحالي:** ${ticketData.rating}/5 ⭐\n**تم التقييم بواسطة:** ${ratedBy.user}`;
      }

      const modal = new ModalBuilder()
        .setCustomId('rating_modal')
        .setTitle('⭐ تقييم الخدمة');

      const ratingInput = new TextInputBuilder()
        .setCustomId('rating_value')
        .setLabel('تقييمك من 1 إلى 5 نجوم')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(1)
        .setPlaceholder('5');

      const commentInput = new TextInputBuilder()
        .setCustomId('rating_comment')
        .setLabel('تعليق إضافي (اختياري)')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(false)
        .setMaxLength(500)
        .setPlaceholder('شكراً للخدمة الممتازة...');

      modal.addComponents(
        new ActionRowBuilder().addComponents(ratingInput),
        new ActionRowBuilder().addComponents(commentInput)
      );

      await interaction.showModal(modal);

      // Send info about current rating if exists
      if (currentRatingText) {
        await interaction.followUp({
          content: `📊 **معلومات التقييم:**${currentRatingText}`,
          ephemeral: true
        });
      }
      
    } catch (error) {
      logger.error('Error showing rating modal:', error);
      throw error;
    }
  }

  static async saveRating(interaction, ratingData) {
    try {
      const ticketData = storage.getTicket(interaction.channel.id);
      
      if (!ticketData) {
        return interaction.reply({
          content: '❌ لم يتم العثور على بيانات التذكرة.',
          ephemeral: true
        });
      }

      // Update ticket with rating
      ticketData.rating = ratingData.rating;
      ticketData.ratingComment = ratingData.comment;
      ticketData.ratedBy = ratingData.ratedBy;
      ticketData.ratedAt = Date.now();
      
      storage.setTicket(interaction.channel.id, ticketData);
      storage.addRating(ratingData.rating);

      // Create rating embed
      const embed = new EmbedBuilder()
        .setColor(config.COLORS.SUCCESS)
        .setTitle('⭐ تم حفظ التقييم بنجاح')
        .setThumbnail(config.SERVER_ICON)
        .setDescription(`
          \`\`\`
          ╔══════════════════════════════════════╗
          ║                 تفاصيل التقييم              ║
          ╚══════════════════════════════════════╝
          \`\`\`
          
          **👤 تم التقييم بواسطة:** ${interaction.user}
          **⭐ التقييم:** ${ratingData.rating}/5 نجوم
          **💬 التعليق:** ${ratingData.comment}
          **🕐 وقت التقييم:** <t:${Math.floor(Date.now() / 1000)}:F>
          
          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
          
          **شكراً لك على تقييم خدماتنا! 💝**
        `)
        .setFooter({ 
          text: `${config.SERVER_NAME} • نقدر آراءكم`, 
          iconURL: config.SERVER_ICON 
        })
        .setTimestamp();

      await interaction.reply({
        embeds: [embed],
        ephemeral: false
      });

      logger.info(`Rating saved: ${ratingData.rating}/5 by ${interaction.user.tag} in ${interaction.channel.name}`);
      
    } catch (error) {
      logger.error('Error saving rating:', error);
      throw error;
    }
  }
}

module.exports = TicketHandler;
