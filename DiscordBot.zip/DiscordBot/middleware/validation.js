const config = require('../config/config');
const logger = require('../utils/logger');

class ValidationMiddleware {
  static validateDiscordId(id, fieldName = 'ID') {
    if (!id || typeof id !== 'string') {
      throw new Error(`${fieldName} is required and must be a string`);
    }
    
    if (!/^\d{17,19}$/.test(id)) {
      throw new Error(`${fieldName} must be a valid Discord snowflake`);
    }
    
    return true;
  }

  static validateTextInput(text, maxLength = 1000, fieldName = 'Text') {
    if (!text || typeof text !== 'string') {
      throw new Error(`${fieldName} is required and must be a string`);
    }
    
    const trimmed = text.trim();
    if (trimmed.length === 0) {
      throw new Error(`${fieldName} cannot be empty`);
    }
    
    if (trimmed.length > maxLength) {
      throw new Error(`${fieldName} cannot exceed ${maxLength} characters`);
    }
    
    // Basic XSS prevention
    const dangerous = /<script|javascript:|on\w+=/i;
    if (dangerous.test(trimmed)) {
      throw new Error(`${fieldName} contains potentially dangerous content`);
    }
    
    return trimmed;
  }

  static validateRating(rating) {
    const num = parseInt(rating);
    if (isNaN(num) || num < 1 || num > 5) {
      throw new Error('Rating must be between 1 and 5');
    }
    return num;
  }

  static validateTicketType(type) {
    const validTypes = config.TICKET_TYPES.map(t => t.id);
    if (!validTypes.includes(type)) {
      throw new Error(`Invalid ticket type. Must be one of: ${validTypes.join(', ')}`);
    }
    return type;
  }

  static sanitizeChannelName(name) {
    // Remove invalid characters for Discord channel names
    return name
      .toLowerCase()
      .replace(/[^a-z0-9\-_]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '')
      .substring(0, 100);
  }

  static validatePermissions(member, requiredRoles = []) {
    if (!member) {
      throw new Error('Member not found');
    }
    
    // Check for admin permissions
    if (member.permissions.has('Administrator')) {
      return true;
    }
    
    // Check required roles
    if (requiredRoles.length > 0) {
      const hasRole = requiredRoles.some(roleId => 
        member.roles.cache.has(roleId)
      );
      
      if (!hasRole) {
        throw new Error('Insufficient permissions');
      }
    }
    
    return true;
  }

  static validateEnvironment() {
    const required = [
      'DISCORD_TOKEN',
      'GUILD_ID',
      'CATEGORY_ID',
      'ADMIN_ROLE_ID',
      'OWNER_ID',
      'RATING_CHANNEL_ID',
      'TRANSCRIPT_CHANNEL_ID'
    ];

    const missing = required.filter(key => !process.env[key]);
    
    if (missing.length > 0) {
      throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
    }

    // Validate Discord IDs
    const discordIds = [
      'GUILD_ID', 'CATEGORY_ID', 'ADMIN_ROLE_ID', 
      'OWNER_ID', 'RATING_CHANNEL_ID', 'TRANSCRIPT_CHANNEL_ID'
    ];

    for (const id of discordIds) {
      try {
        this.validateDiscordId(process.env[id], id);
      } catch (error) {
        logger.warn(`Invalid ${id}: ${error.message}`);
      }
    }

    return true;
  }
}

module.exports = ValidationMiddleware;
