const storage = require('../utils/storage');
const logger = require('../utils/logger');

class CooldownManager {
  static setCooldown(userId, type, duration) {
    try {
      const expires = Date.now() + duration;
      storage.setCooldown(userId, type, expires);
      logger.debug(`Cooldown set for ${userId} - ${type} - expires: ${expires}`);
    } catch (error) {
      logger.error('Failed to set cooldown:', error);
    }
  }

  static isOnCooldown(userId, type) {
    try {
      const expires = storage.getCooldown(userId, type);
      const isOnCooldown = expires > Date.now();
      
      if (!isOnCooldown && expires > 0) {
        // Clean up expired cooldown
        storage.setCooldown(userId, type, 0);
      }
      
      return isOnCooldown;
    } catch (error) {
      logger.error('Failed to check cooldown:', error);
      return false;
    }
  }

  static getRemainingTime(userId, type) {
    try {
      const expires = storage.getCooldown(userId, type);
      const remaining = expires - Date.now();
      return Math.max(0, remaining);
    } catch (error) {
      logger.error('Failed to get remaining time:', error);
      return 0;
    }
  }

  static clearCooldown(userId, type) {
    try {
      storage.setCooldown(userId, type, 0);
      logger.debug(`Cooldown cleared for ${userId} - ${type}`);
    } catch (error) {
      logger.error('Failed to clear cooldown:', error);
    }
  }

  static getAllCooldowns(userId) {
    try {
      return storage.data.cooldowns[userId] || {};
    } catch (error) {
      logger.error('Failed to get all cooldowns:', error);
      return {};
    }
  }

  static clearExpiredCooldowns() {
    try {
      const now = Date.now();
      let cleaned = 0;
      
      for (const userId in storage.data.cooldowns) {
        for (const type in storage.data.cooldowns[userId]) {
          if (storage.data.cooldowns[userId][type] < now) {
            delete storage.data.cooldowns[userId][type];
            cleaned++;
          }
        }
        
        // Remove empty user entries
        if (Object.keys(storage.data.cooldowns[userId]).length === 0) {
          delete storage.data.cooldowns[userId];
        }
      }
      
      if (cleaned > 0) {
        storage.save();
        logger.debug(`Cleaned ${cleaned} expired cooldowns`);
      }
      
      return cleaned;
    } catch (error) {
      logger.error('Failed to clean expired cooldowns:', error);
      return 0;
    }
  }

  // Rate limiting for specific actions
  static checkRateLimit(userId, action, maxAttempts = 5, windowMs = 60000) {
    try {
      const key = `ratelimit_${action}`;
      const now = Date.now();
      const window = now - windowMs;
      
      // Get or create rate limit data
      if (!storage.data.cooldowns[userId]) {
        storage.data.cooldowns[userId] = {};
      }
      
      if (!storage.data.cooldowns[userId][key]) {
        storage.data.cooldowns[userId][key] = [];
      }
      
      // Clean old attempts
      storage.data.cooldowns[userId][key] = storage.data.cooldowns[userId][key]
        .filter(timestamp => timestamp > window);
      
      // Check if rate limited
      if (storage.data.cooldowns[userId][key].length >= maxAttempts) {
        return {
          limited: true,
          resetTime: storage.data.cooldowns[userId][key][0] + windowMs
        };
      }
      
      // Add current attempt
      storage.data.cooldowns[userId][key].push(now);
      storage.save();
      
      return {
        limited: false,
        attempts: storage.data.cooldowns[userId][key].length,
        remaining: maxAttempts - storage.data.cooldowns[userId][key].length
      };
      
    } catch (error) {
      logger.error('Failed to check rate limit:', error);
      return { limited: false, attempts: 0, remaining: maxAttempts };
    }
  }
}

module.exports = CooldownManager;
