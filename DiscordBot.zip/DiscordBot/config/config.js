require('dotenv').config();

const config = {
  // Discord Configuration
  DISCORD_TOKEN: process.env.DISCORD_TOKEN,
  GUILD_ID: process.env.GUILD_ID,
  CATEGORY_ID: process.env.CATEGORY_ID,
  ADMIN_ROLE_ID: process.env.ADMIN_ROLE_ID,
  OWNER_ID: process.env.OWNER_ID,
  RATING_CHANNEL_ID: process.env.RATING_CHANNEL_ID,
  TRANSCRIPT_CHANNEL_ID: process.env.TRANSCRIPT_CHANNEL_ID,

  // Bot Configuration
  NODE_ENV: process.env.NODE_ENV || 'development',
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
  
  // Limits
  LIMITS: {
    MAX_TICKETS_PER_USER: parseInt(process.env.MAX_TICKETS_PER_USER) || 2,
    COOLDOWN_TIME: 30000, // 30 seconds
    MAX_RATING_LENGTH: 500
  },

  // Working Hours
  WORKING_HOURS: {
    START: process.env.WORKING_HOURS_START || "12:00",
    END: process.env.WORKING_HOURS_END || "01:00",
    TIMEZONE: process.env.WORKING_HOURS_TIMEZONE || "Africa/Cairo",
    DAYS: ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
  },

  // Colors
  COLORS: {
    PRIMARY: "#00FFFF",
    SUCCESS: "#57F287",
    ERROR: "#ED4245",
    WARNING: "#FEE75C",
    INFO: "#5865F2",
    BLURPLE: "#5865F2",
    SECONDARY: "#2B2D31",
    PURPLE: "#9B59B6",
    ORANGE: "#E67E22",
    CYAN: "#00B8D4"
  },

  // Emojis
  EMOJIS: {
    TICKET: "🎫",
    GAMES: "🎮",
    DISCORD: "💠",
    SHIELD: "🛡️",
    STAR: "⭐",
    CRITERIA: "📋",
    SUPPORT: "💬",
    ADMIN: "👑",
    REPORT: "⚠️",
    TIME: "⏰",
    SUCCESS: "✅",
    ERROR: "❌",
    WARNING: "⚠️",
    INFO: "ℹ️"
  },

  // Server Information
  SERVER_NAME: process.env.SERVER_NAME || "Discord Server",
  SERVER_ICON: "https://cdn.discordapp.com/attachments/1275206091254939690/1275206255031779409/ChatGPT_Image_Aug_21_2025_11_13_29_AM_1756081515997.png?ex=66c4de19&is=66c38c99&hm=ca4a3ae8e35b6b5d2f671b25ac4bdd69a1db5bc28ceafb0a7f8c31aa6b8a19fc&",

  // Ticket Types
  TICKET_TYPES: [
    {
      id: "discord_support",
      label: "دعم ديسكورد",
      emoji: "💠",
      prefix: "discord"
    },
    {
      id: "games_support",
      label: "دعم الألعاب", 
      emoji: "🎮",
      prefix: "game"
    },
    {
      id: "report_issue",
      label: "الإبلاغ عن مشكلة",
      emoji: "⚠️",
      prefix: "report"
    },
    {
      id: "admin_application",
      label: "تقديم إداري",
      emoji: "👑",
      prefix: "admin"
    }
  ],

  // Storage
  STORAGE_FILE: './data/tickets.json',
  BACKUP_INTERVAL: 1800000, // 30 minutes
  MAX_BACKUPS: 10
};

// Validation
function validateConfig() {
  const required = [
    'DISCORD_TOKEN',
    'GUILD_ID',
    'CATEGORY_ID',
    'ADMIN_ROLE_ID',
    'OWNER_ID',
    'RATING_CHANNEL_ID',
    'TRANSCRIPT_CHANNEL_ID'
  ];

  const missing = required.filter(key => !config[key]);
  
  if (missing.length > 0) {
    console.error(`Missing required configuration: ${missing.join(', ')}`);
    console.error('Please check your .env file and ensure all required variables are set.');
    process.exit(1);
  }

  // Validate Discord IDs (should be snowflakes)
  const discordIds = [
    'GUILD_ID', 'CATEGORY_ID', 'ADMIN_ROLE_ID', 
    'OWNER_ID', 'RATING_CHANNEL_ID', 'TRANSCRIPT_CHANNEL_ID'
  ];

  for (const id of discordIds) {
    if (!/^\d{17,19}$/.test(config[id])) {
      console.warn(`Invalid Discord ID format for ${id}: ${config[id]}`);
    }
  }

  console.log('Configuration validation passed');
}

// Run validation
validateConfig();

module.exports = config;
