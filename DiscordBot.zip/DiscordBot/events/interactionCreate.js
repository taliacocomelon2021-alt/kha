const CommandHandler = require('../handlers/commands');
const InteractionHandler = require('../handlers/interactions');
const logger = require('../utils/logger');

module.exports = (client) => {
  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        await CommandHandler.handleCommand(interaction);
      } 
      else if (interaction.isStringSelectMenu()) {
        await InteractionHandler.handleSelectMenu(interaction);
      } 
      else if (interaction.isModalSubmit()) {
        await InteractionHandler.handleModal(interaction);
      } 
      else if (interaction.isButton()) {
        await InteractionHandler.handleButton(interaction);
      }
    } catch (error) {
      logger.error('Error in interactionCreate event:', error);
      
      const errorMessage = '❌ حدث خطأ غير متوقع. يرجى المحاولة لاحقاً.';
      
      try {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: errorMessage, ephemeral: true });
        } else {
          await interaction.reply({ content: errorMessage, ephemeral: true });
        }
      } catch (replyError) {
        logger.error('Failed to send error message:', replyError);
      }
    }
  });
};
