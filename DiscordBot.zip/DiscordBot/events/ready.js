const logger = require('../utils/logger');
const storage = require('../utils/storage');
const CommandHandler = require('../handlers/commands');
const config = require('../config/config');

module.exports = (client) => {
  client.once('clientReady', async () => {
    try {
      logger.info(`✅ Logged in as ${client.user.tag}`);
      
      // Set bot status
      client.user.setActivity('🎫 نظام التذاكر', { type: 3 }); // 3 = WATCHING
      
      // Get the guild
      const guild = client.guilds.cache.get(config.GUILD_ID);
      if (!guild) {
        logger.error(`Guild with ID ${config.GUILD_ID} not found`);
        process.exit(1);
      }

      // Register commands
      await CommandHandler.registerCommands(guild);
      logger.info('✅ Commands registered successfully');

      // Clean expired cooldowns on startup
      storage.clearExpiredCooldowns();
      
      // Log bot statistics
      const stats = storage.getStats();
      logger.info(`Bot Statistics: ${stats.totalTickets} total tickets, ${stats.closedTickets} closed, ${stats.averageRating.toFixed(1)} avg rating`);
      
      // Schedule periodic cleanup
      setInterval(() => {
        storage.clearExpiredCooldowns();
        logger.debug('Cleaned expired cooldowns');
      }, 300000); // 5 minutes

      logger.info('🤖 Bot is ready and operational!');
      
    } catch (error) {
      logger.error('Error in ready event:', error);
      process.exit(1);
    }
  });
};
