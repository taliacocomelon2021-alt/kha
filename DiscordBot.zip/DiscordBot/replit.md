# Overview

A comprehensive Discord bot that provides a complete ticket system for managing user support requests. The bot features multiple support categories (Discord support, Games support, Issue reporting), admin controls, a rating system, and automatic transcript generation. Built with Discord.js v14, it uses a modular architecture for easy maintenance and scaling, with JSON-based data persistence and automated backup functionality.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Architecture
- **Event-driven architecture** using Discord.js v14 with proper event handlers for interactions, commands, and ready states
- **Modular command system** with separate handlers for slash commands, select menus, modals, and buttons
- **Middleware layer** for cooldown management and input validation to prevent spam and ensure data integrity
- **Error handling system** with comprehensive logging and graceful error recovery

## Data Management
- **JSON-based storage** system with automatic backup rotation and file size management
- **In-memory caching** of frequently accessed data with periodic cleanup of expired cooldowns
- **Atomic operations** for ticket creation, updates, and statistics tracking
- **Data validation** with XSS prevention and input sanitization

## Permission System
- **Role-based access control** using Discord permissions and admin role verification
- **Per-channel permissions** automatically configured when tickets are created
- **User limitation system** preventing spam with configurable ticket limits per user

## Component Structure
- **Ticket lifecycle management** from creation through rating and archiving
- **Interactive UI components** using Discord's select menus, modals, and buttons
- **Real-time status tracking** with health checks and performance monitoring
- **Automated transcript generation** and archival to designated channels

# External Dependencies

## Core Dependencies
- **Discord.js v14.22.1** - Main Discord API wrapper for bot functionality
- **dotenv v17.2.1** - Environment variable management for configuration

## Discord API Integration
- **Guild-specific slash commands** registered per server for ticket management
- **Channel management** with automatic creation, permission configuration, and cleanup
- **Message components** including embeds, select menus, modals, and buttons
- **Role and permission verification** for admin controls and access management

## File System Dependencies
- **Local JSON storage** with configurable file paths and backup directories
- **Log file management** with automatic rotation and size limits
- **Automatic backup system** with configurable intervals and retention policies

## Configuration Management
- **Environment-based configuration** using .env files for sensitive data
- **JSON configuration files** for bot settings, colors, emojis, and ticket types
- **Runtime configuration validation** ensuring all required settings are present