const { EmbedBuilder } = require('discord.js');
const storage = require('../utils/storage');
const config = require('../config/config');
const logger = require('../utils/logger');

module.exports = {
  async execute(interaction) {
    try {
      const stats = storage.getStats();
      
      // Calculate additional stats
      const openTickets = Object.values(storage.data.tickets).filter(
        ticket => ticket.status === 'open'
      ).length;
      
      const claimedTickets = Object.values(storage.data.tickets).filter(
        ticket => ticket.claimed
      ).length;

      // Get type distribution
      const typeStats = {};
      Object.values(storage.data.tickets).forEach(ticket => {
        typeStats[ticket.type] = (typeStats[ticket.type] || 0) + 1;
      });

      const embed = new EmbedBuilder()
        .setColor(config.COLORS.INFO)
        .setTitle(`${config.EMOJIS.TICKET} إحصائيات نظام التذاكر`)
        .setDescription(`
          \`\`\`
          ╔══════════════════════════╗
          ║         الإحصائيات          ║
          ╚══════════════════════════╝
          \`\`\`
        `)
        .addFields([
          {
            name: '📊 الأرقام العامة',
            value: `
              > 🎫 إجمالي التذاكر: **${stats.totalTickets}**
              > 🔓 التذاكر المفتوحة: **${openTickets}**
              > 🔒 التذاكر المغلقة: **${stats.closedTickets}**
              > 👑 التذاكر المستلمة: **${claimedTickets}**
            `,
            inline: true
          },
          {
            name: '⭐ التقييمات',
            value: `
              > 📈 متوسط التقييم: **${stats.averageRating.toFixed(1)}/5**
              > 📝 عدد التقييمات: **${stats.ratingCount}**
              > 🎯 معدل التقييم: **${stats.totalTickets > 0 ? ((stats.ratingCount / stats.totalTickets) * 100).toFixed(1) : 0}%**
            `,
            inline: true
          }
        ])
        .setThumbnail(config.SERVER_ICON)
        .setFooter({ 
          text: `${config.SERVER_NAME} • آخر تحديث`, 
          iconURL: config.SERVER_ICON 
        })
        .setTimestamp();

      // Add type distribution if there are tickets
      if (Object.keys(typeStats).length > 0) {
        const typeDistribution = Object.entries(typeStats)
          .map(([type, count]) => {
            const typeInfo = config.TICKET_TYPES.find(t => t.id === type);
            const emoji = typeInfo?.emoji || '📋';
            const label = typeInfo?.label || type;
            return `> ${emoji} ${label}: **${count}**`;
          })
          .join('\n');

        embed.addFields({
          name: '📋 توزيع أنواع التذاكر',
          value: typeDistribution,
          inline: false
        });
      }

      await interaction.reply({ embeds: [embed] });

      logger.info(`Stats command executed by ${interaction.user.tag}`);
      
    } catch (error) {
      logger.error('Error executing stats command:', error);
      throw error;
    }
  }
};
