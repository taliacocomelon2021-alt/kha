const { EmbedBuilder } = require('discord.js');
const storage = require('../utils/storage');
const config = require('../config/config');
const logger = require('../utils/logger');

module.exports = {
  async execute(interaction) {
    try {
      const startTime = Date.now();
      
      // Check bot latency
      const botLatency = interaction.client.ws.ping;
      
      // Check storage health
      const storageHealthy = storage.healthCheck();
      
      // Check required channels
      const channelChecks = await Promise.allSettled([
        interaction.client.channels.fetch(config.CATEGORY_ID),
        interaction.client.channels.fetch(config.RATING_CHANNEL_ID),
        interaction.client.channels.fetch(config.TRANSCRIPT_CHANNEL_ID)
      ]);

      const channelsHealthy = channelChecks.every(result => result.status === 'fulfilled');
      
      // Check guild and roles
      const guild = interaction.guild;
      const adminRole = guild.roles.cache.get(config.ADMIN_ROLE_ID);
      
      const responseTime = Date.now() - startTime;
      
      // Determine overall health
      const overallHealthy = storageHealthy && channelsHealthy && adminRole && botLatency < 200;
      
      const embed = new EmbedBuilder()
        .setColor(overallHealthy ? config.COLORS.SUCCESS : config.COLORS.WARNING)
        .setTitle(`${overallHealthy ? '✅' : '⚠️'} فحص حالة البوت`)
        .addFields([
          {
            name: '🏓 زمن الاستجابة',
            value: `
              > Bot Latency: **${botLatency}ms**
              > Response Time: **${responseTime}ms**
            `,
            inline: true
          },
          {
            name: '💾 حالة التخزين',
            value: `
              > Database: **${storageHealthy ? '✅ يعمل' : '❌ خطأ'}**
              > Total Tickets: **${storage.getStats().totalTickets}**
            `,
            inline: true
          },
          {
            name: '📋 القنوات والأذونات',
            value: `
              > Category: **${channelChecks[0].status === 'fulfilled' ? '✅' : '❌'}**
              > Rating Channel: **${channelChecks[1].status === 'fulfilled' ? '✅' : '❌'}**
              > Transcript Channel: **${channelChecks[2].status === 'fulfilled' ? '✅' : '❌'}**
              > Admin Role: **${adminRole ? '✅' : '❌'}**
            `,
            inline: false
          }
        ])
        .setFooter({ 
          text: `System Check • ${new Date().toLocaleString('ar-SA')}`, 
          iconURL: config.SERVER_ICON 
        })
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });

      logger.info(`Health check executed by ${interaction.user.tag} - Overall: ${overallHealthy ? 'Healthy' : 'Issues detected'}`);
      
    } catch (error) {
      logger.error('Error executing health check:', error);
      throw error;
    }
  }
};
