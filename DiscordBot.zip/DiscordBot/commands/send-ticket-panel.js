const EmbedManager = require('../utils/embeds');
const logger = require('../utils/logger');

module.exports = {
  async execute(interaction) {
    try {
      const panel = EmbedManager.ticketPanel();
      
      await interaction.channel.send(panel);
      
      await interaction.reply({
        content: '✅ تم إرسال لوحة التذاكر بنجاح',
        ephemeral: true
      });

      logger.info(`Ticket panel sent by ${interaction.user.tag} in ${interaction.channel.name}`);
      
    } catch (error) {
      logger.error('Error sending ticket panel:', error);
      throw error;
    }
  }
};
