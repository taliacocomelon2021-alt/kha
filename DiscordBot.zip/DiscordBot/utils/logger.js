const fs = require('fs');
const path = require('path');
const config = require('../config/config');

class Logger {
  constructor() {
    this.logDir = './logs';
    this.logFile = path.join(this.logDir, 'bot.log');
    this.errorFile = path.join(this.logDir, 'error.log');
    this.maxLogSize = 10 * 1024 * 1024; // 10MB
    this.maxLogFiles = 5;
    
    this.init();
  }

  init() {
    // Create logs directory if it doesn't exist
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }
  }

  formatMessage(level, message, ...args) {
    const timestamp = new Date().toISOString();
    const formattedArgs = args.length > 0 ? ' ' + args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
    ).join(' ') : '';
    
    return `[${timestamp}] [${level.toUpperCase()}] ${message}${formattedArgs}`;
  }

  writeToFile(filename, message) {
    try {
      // Check file size and rotate if needed
      if (fs.existsSync(filename)) {
        const stats = fs.statSync(filename);
        if (stats.size > this.maxLogSize) {
          this.rotateLog(filename);
        }
      }

      fs.appendFileSync(filename, message + '\n');
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }

  rotateLog(filename) {
    try {
      const ext = path.extname(filename);
      const base = path.basename(filename, ext);
      const dir = path.dirname(filename);

      // Move existing log files
      for (let i = this.maxLogFiles - 1; i > 0; i--) {
        const oldFile = path.join(dir, `${base}.${i}${ext}`);
        const newFile = path.join(dir, `${base}.${i + 1}${ext}`);
        
        if (fs.existsSync(oldFile)) {
          if (i === this.maxLogFiles - 1) {
            fs.unlinkSync(oldFile); // Delete the oldest log
          } else {
            fs.renameSync(oldFile, newFile);
          }
        }
      }

      // Move current log to .1
      const rotatedFile = path.join(dir, `${base}.1${ext}`);
      fs.renameSync(filename, rotatedFile);
    } catch (error) {
      console.error('Failed to rotate log file:', error);
    }
  }

  log(level, message, ...args) {
    const formattedMessage = this.formatMessage(level, message, ...args);
    
    // Console output with colors
    if (config.NODE_ENV !== 'production') {
      const colors = {
        error: '\x1b[31m',   // Red
        warn: '\x1b[33m',    // Yellow
        info: '\x1b[36m',    // Cyan
        debug: '\x1b[35m',   // Magenta
        reset: '\x1b[0m'
      };
      
      console.log(`${colors[level] || colors.reset}${formattedMessage}${colors.reset}`);
    }

    // File output
    this.writeToFile(this.logFile, formattedMessage);
    
    // Error file for errors and warnings
    if (level === 'error' || level === 'warn') {
      this.writeToFile(this.errorFile, formattedMessage);
    }
  }

  error(message, ...args) {
    this.log('error', message, ...args);
  }

  warn(message, ...args) {
    this.log('warn', message, ...args);
  }

  info(message, ...args) {
    this.log('info', message, ...args);
  }

  debug(message, ...args) {
    if (config.LOG_LEVEL === 'debug') {
      this.log('debug', message, ...args);
    }
  }

  // Clean old log files
  cleanup() {
    try {
      const files = fs.readdirSync(this.logDir);
      const logFiles = files.filter(file => file.endsWith('.log'));
      
      logFiles.forEach(file => {
        const filePath = path.join(this.logDir, file);
        const stats = fs.statSync(filePath);
        const age = Date.now() - stats.mtime.getTime();
        const maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days
        
        if (age > maxAge) {
          fs.unlinkSync(filePath);
          this.info(`Deleted old log file: ${file}`);
        }
      });
    } catch (error) {
      this.error('Failed to cleanup old logs:', error);
    }
  }
}

module.exports = new Logger();
