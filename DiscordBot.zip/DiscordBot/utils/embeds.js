const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config');

class EmbedManager {
  // Ticket panel embed with support categories
  static ticketPanel() {
    const embed = new EmbedBuilder()
      .setColor(config.COLORS.PRIMARY)
      .setTitle(`${config.EMOJIS.TICKET} نظام التذاكر`)
      .setDescription(`
        \`\`\`
        ╔══════════════════════════════════════╗
        ║           مرحباً بك في ${config.SERVER_NAME}            ║
        ╚══════════════════════════════════════╝
        \`\`\`
        
        ${config.EMOJIS.INFO} **اختر نوع الخدمة التي تحتاجها:**
        
        ${config.EMOJIS.DISCORD} **دعم ديسكورد** - مشاكل متعلقة بالسيرفر
        ${config.EMOJIS.GAMES} **دعم الألعاب** - مشاكل متعلقة بالألعاب  
        ${config.EMOJIS.REPORT} **الإبلاغ عن مشكلة** - للإبلاغ عن المخالفات
        👑 **تقديم إداري** - للتقديم على منصب إداري
        
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        ${config.EMOJIS.WARNING} **ملاحظات مهمة:**
        • الحد الأقصى: ${config.LIMITS.MAX_TICKETS_PER_USER} تذاكر مفتوحة
        • سيتم الرد عليك في أسرع وقت ممكن  
        • تأكد من تقديم تفاصيل واضحة ودقيقة
        
        ${config.EMOJIS.TIME} **ساعات العمل:** ${config.WORKING_HOURS.START} - ${config.WORKING_HOURS.END}
        
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      `)
      .setImage(config.SERVER_ICON)
      .setThumbnail(config.SERVER_ICON)
      .setFooter({ 
        text: `${config.SERVER_NAME} • نظام التذاكر المتطور`, 
        iconURL: config.SERVER_ICON 
      })
      .setTimestamp();

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_support')
      .setPlaceholder('اختر نوع الدعم...')
      .addOptions(
        config.TICKET_TYPES.map(type => ({
          label: type.label,
          value: type.id,
          emoji: type.emoji
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    return { embeds: [embed], components: [row] };
  }

  // Individual ticket embed
  static ticketEmbed(type, user, ticketData) {
    const typeInfo = config.TICKET_TYPES.find(t => t.id === type);
    
    const embed = new EmbedBuilder()
      .setColor(config.COLORS.INFO)
      .setTitle(`${typeInfo?.emoji || config.EMOJIS.TICKET} ${typeInfo?.label || 'تذكرة دعم'}`)
      .setDescription(`
        \`\`\`
        ╔══════════════════════════════════════╗
        ║                معلومات التذكرة             ║
        ╚══════════════════════════════════════╝
        \`\`\`
        
        **👤 صاحب التذكرة:** ${user}
        **📋 نوع التذكرة:** ${typeInfo?.label || 'غير محدد'}
        **🕐 وقت الإنشاء:** <t:${Math.floor(ticketData.createdAt / 1000)}:F>
        **🆔 معرف التذكرة:** \`${ticketData.ticketId || ticketData.channelId}\`
        
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        ${type === 'discord_support' || type === 'report_issue' ? '📝 **اكتب مشكلتك ولو حد ضرك هنا:**' : ''}
      `)
      .setThumbnail(user.displayAvatarURL())
      .setImage(config.SERVER_ICON)
      .setFooter({ 
        text: `${config.SERVER_NAME} • نظام التذاكر المتطور`, 
        iconURL: config.SERVER_ICON 
      })
      .setTimestamp();

    // Add game-specific fields if it's a game support ticket
    if (type === 'games_support' && ticketData.game) {
      embed.addFields([
        { name: '🎮 اللعبة', value: ticketData.game, inline: true },
        { name: '👤 المُبلغ عنه', value: ticketData.reported, inline: true },
        { name: '🔍 تدخل المالك', value: ticketData.needOwner ? 'نعم' : 'لا', inline: true },
        { name: '📝 وصف المشكلة', value: ticketData.problem || 'لم يتم تحديد وصف' }
      ]);
    }

    // Add problem details for basic support tickets
    if ((type === 'discord_support' || type === 'report_issue') && ticketData.problemDescription) {
      embed.addFields([
        { name: '📝 وصف المشكلة', value: ticketData.problemDescription },
        { name: '⚠️ الشخص المتسبب في الضرر', value: ticketData.personCausingHarm || 'لا يوجد', inline: true }
      ]);
    }

    // Add admin application fields
    if (type === 'admin_application' && ticketData.age) {
      embed.addFields([
        { name: '📅 العمر', value: ticketData.age, inline: true },
        { name: '👤 الاسم', value: ticketData.name, inline: true },
        { name: '🌍 البلد', value: ticketData.country, inline: true },
        { name: '💼 الخبرة في الإدارة', value: ticketData.experience || 'لا توجد خبرة سابقة' }
      ]);
    }

    return embed;
  }

  // Ticket control buttons
  static ticketControls(isClaimed = false, claimedBy = null, ticketData = null) {
    const claimButton = new ButtonBuilder()
      .setCustomId('claim_ticket')
      .setLabel(isClaimed ? `مستلمة بواسطة` : 'استلام التذكرة')
      .setStyle(isClaimed ? ButtonStyle.Success : ButtonStyle.Primary)
      .setEmoji(config.EMOJIS.ADMIN)
      .setDisabled(isClaimed);

    const rateButton = new ButtonBuilder()
      .setCustomId('rate_ticket')
      .setLabel('تقييم الخدمة')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('⭐');

    const closeButton = new ButtonBuilder()
      .setCustomId('close_ticket')
      .setLabel('إغلاق التذكرة')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒');

    return new ActionRowBuilder().addComponents(claimButton, rateButton, closeButton);
  }

  // Close confirmation buttons
  static closeConfirmation() {
    const confirmButton = new ButtonBuilder()
      .setCustomId('confirm_close')
      .setLabel('تأكيد الإغلاق')
      .setStyle(ButtonStyle.Danger)
      .setEmoji(config.EMOJIS.SUCCESS);

    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel_close')
      .setLabel('إلغاء')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji(config.EMOJIS.ERROR);

    return new ActionRowBuilder().addComponents(confirmButton, cancelButton);
  }

  // Rating system embed
  static ratingEmbed(ticketId, staffMember) {
    const embed = new EmbedBuilder()
      .setColor(config.COLORS.WARNING)
      .setTitle(`${config.EMOJIS.STAR} تقييم الخدمة`)
      .setDescription(`
        شكراً لاستخدام نظام الدعم!
        
        يرجى تقييم جودة الخدمة المقدمة من ${staffMember}
        اختر عدد النجوم من 1 إلى 5:
        
        ⭐ = سيء جداً
        ⭐⭐ = سيء
        ⭐⭐⭐ = متوسط
        ⭐⭐⭐⭐ = جيد
        ⭐⭐⭐⭐⭐ = ممتاز
      `)
      .setFooter({ 
        text: 'تقييمك يساعدنا على تحسين خدماتنا', 
        iconURL: config.SERVER_ICON 
      });

    const buttons = [];
    for (let i = 1; i <= 5; i++) {
      buttons.push(
        new ButtonBuilder()
          .setCustomId(`rate_${i}`)
          .setLabel(`${i}`)
          .setStyle(ButtonStyle.Primary)
          .setEmoji('⭐')
      );
    }

    const row = new ActionRowBuilder().addComponents(buttons);
    return { embeds: [embed], components: [row] };
  }

  // Transcript embed
  static transcriptEmbed(data) {
    const embed = new EmbedBuilder()
      .setColor(config.COLORS.SUCCESS)
      .setTitle(`${config.EMOJIS.TICKET} نسخة محادثة التذكرة`)
      .setDescription(`
        **اسم القناة:** ${data.channelName}
        **صاحب التذكرة:** ${data.creator}
        **المسؤول المختص:** ${data.claimer || 'لم يتم الاستلام'}
        **التقييم:** ${data.rating ? '⭐'.repeat(data.rating) : 'لم يتم التقييم'}
        **تاريخ الإنشاء:** ${data.createdAt}
        **تاريخ الإغلاق:** ${data.closedAt}
        **مدة التذكرة:** ${data.duration}
      `)
      .setFooter({ 
        text: `${config.SERVER_NAME} • أرشيف التذاكر`, 
        iconURL: config.SERVER_ICON 
      })
      .setTimestamp();

    return embed;
  }

  // Error embed
  static errorEmbed(title, description) {
    return new EmbedBuilder()
      .setColor(config.COLORS.ERROR)
      .setTitle(`${config.EMOJIS.ERROR} ${title}`)
      .setDescription(description)
      .setTimestamp();
  }

  // Success embed
  static successEmbed(title, description) {
    return new EmbedBuilder()
      .setColor(config.COLORS.SUCCESS)
      .setTitle(`${config.EMOJIS.SUCCESS} ${title}`)
      .setDescription(description)
      .setTimestamp();
  }

  // Warning embed
  static warningEmbed(title, description) {
    return new EmbedBuilder()
      .setColor(config.COLORS.WARNING)
      .setTitle(`${config.EMOJIS.WARNING} ${title}`)
      .setDescription(description)
      .setTimestamp();
  }

  // Info embed
  static infoEmbed(title, description) {
    return new EmbedBuilder()
      .setColor(config.COLORS.INFO)
      .setTitle(`${config.EMOJIS.INFO} ${title}`)
      .setDescription(description)
      .setTimestamp();
  }
}

module.exports = EmbedManager;
