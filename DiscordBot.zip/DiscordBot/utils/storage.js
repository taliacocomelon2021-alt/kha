const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const config = require('../config/config');

class Storage {
  constructor() {
    this.dataFile = config.STORAGE_FILE;
    this.backupDir = './data/backups';
    this.data = {
      tickets: {},
      ratings: {},
      cooldowns: {},
      stats: {
        totalTickets: 0,
        closedTickets: 0,
        averageRating: 0,
        ratingCount: 0
      }
    };
  }

  init() {
    try {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dataFile);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
        logger.info('Created data directory');
      }

      // Create backup directory
      if (!fs.existsSync(this.backupDir)) {
        fs.mkdirSync(this.backupDir, { recursive: true });
        logger.info('Created backup directory');
      }

      // Load existing data
      this.load();

      // Setup automatic backup
      setInterval(() => {
        this.backup();
      }, config.BACKUP_INTERVAL);

      logger.info('Storage initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize storage:', error);
      throw error;
    }
  }

  load() {
    try {
      if (fs.existsSync(this.dataFile)) {
        const rawData = fs.readFileSync(this.dataFile, 'utf8');
        this.data = { ...this.data, ...JSON.parse(rawData) };
        logger.info('Storage data loaded successfully');
      } else {
        logger.info('No existing data file found, starting with empty data');
        this.save();
      }
    } catch (error) {
      logger.error('Failed to load storage data:', error);
      throw error;
    }
  }

  save() {
    try {
      fs.writeFileSync(this.dataFile, JSON.stringify(this.data, null, 2));
      logger.debug('Storage data saved');
    } catch (error) {
      logger.error('Failed to save storage data:', error);
      throw error;
    }
  }

  backup() {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupFile = path.join(this.backupDir, `tickets-${timestamp}.json`);
      
      fs.writeFileSync(backupFile, JSON.stringify(this.data, null, 2));
      
      // Clean old backups
      this.cleanOldBackups();
      
      logger.info(`Backup created: ${backupFile}`);
    } catch (error) {
      logger.error('Failed to create backup:', error);
    }
  }

  cleanOldBackups() {
    try {
      const backups = fs.readdirSync(this.backupDir)
        .filter(file => file.startsWith('tickets-'))
        .map(file => ({
          name: file,
          path: path.join(this.backupDir, file),
          time: fs.statSync(path.join(this.backupDir, file)).mtime
        }))
        .sort((a, b) => b.time - a.time);

      if (backups.length > config.MAX_BACKUPS) {
        const toDelete = backups.slice(config.MAX_BACKUPS);
        toDelete.forEach(backup => {
          fs.unlinkSync(backup.path);
          logger.debug(`Deleted old backup: ${backup.name}`);
        });
      }
    } catch (error) {
      logger.error('Failed to clean old backups:', error);
    }
  }

  // Ticket methods
  setTicket(channelId, ticketData) {
    this.data.tickets[channelId] = ticketData;
    this.save();
  }

  getTicket(channelId) {
    return this.data.tickets[channelId] || null;
  }

  deleteTicket(channelId) {
    delete this.data.tickets[channelId];
    this.save();
  }

  getUserTickets(userId) {
    return Object.values(this.data.tickets).filter(
      ticket => ticket.userId === userId && ticket.status === 'open'
    );
  }

  // Stats methods
  incrementTotalTickets() {
    this.data.stats.totalTickets++;
    this.save();
  }

  incrementClosedTickets() {
    this.data.stats.closedTickets++;
    this.save();
  }

  addRating(ticketId, ratingData) {
    this.data.ratings[ticketId] = ratingData;
    this.updateRatingStats();
    this.save();
  }

  updateRatingStats() {
    const ratings = Object.values(this.data.ratings);
    if (ratings.length > 0) {
      const total = ratings.reduce((sum, rating) => sum + rating.rating, 0);
      this.data.stats.averageRating = total / ratings.length;
      this.data.stats.ratingCount = ratings.length;
    }
  }

  getStats() {
    return this.data.stats;
  }

  // Cooldown methods
  setCooldown(userId, type, expires) {
    if (!this.data.cooldowns[userId]) {
      this.data.cooldowns[userId] = {};
    }
    this.data.cooldowns[userId][type] = expires;
    this.save();
  }

  getCooldown(userId, type) {
    return this.data.cooldowns[userId]?.[type] || 0;
  }

  clearExpiredCooldowns() {
    const now = Date.now();
    for (const userId in this.data.cooldowns) {
      for (const type in this.data.cooldowns[userId]) {
        if (this.data.cooldowns[userId][type] < now) {
          delete this.data.cooldowns[userId][type];
        }
      }
      if (Object.keys(this.data.cooldowns[userId]).length === 0) {
        delete this.data.cooldowns[userId];
      }
    }
    this.save();
  }

  // Health check
  healthCheck() {
    try {
      const testData = { test: Date.now() };
      const testFile = path.join(path.dirname(this.dataFile), 'health-check.json');
      
      fs.writeFileSync(testFile, JSON.stringify(testData));
      const readData = JSON.parse(fs.readFileSync(testFile, 'utf8'));
      fs.unlinkSync(testFile);
      
      return readData.test === testData.test;
    } catch (error) {
      logger.error('Storage health check failed:', error);
      return false;
    }
  }
}

module.exports = new Storage();
