const { 
  Client, 
  GatewayIntentBits, 
  Partials, 
  ChannelType, 
  PermissionsBitField,
  AttachmentBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder
} = require('discord.js');

const config = require('./config.json');
const storage = require('./utils/storage');
const EmbedManager = require('./utils/embeds');

// Create client instance
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

// Ready event
client.on('ready', async () => {
  const guild = client.guilds.cache.get(config.GUILD_ID);
  if (guild) {
    try {
      await guild.commands.set([
        {
          name: 'send-ticket-panel',
          description: 'يرسل لوحة التذاكر'
        },
        {
          name: 'ticket-stats',
          description: 'يعرض إحصائيات نظام التذاكر'
        }
      ]);
      console.log(`✅ Logged in as ${client.user.tag}`);
      console.log('✅ Commands registered successfully');
    } catch (error) {
      console.error('❌ Error registering commands:', error);
    }
  }
});

// Command handler
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  switch (interaction.commandName) {
    case 'send-ticket-panel': {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: '❌ عذراً، هذا الأمر للإدارة فقط',
          ephemeral: true
        });
      }

      const panel = EmbedManager.ticketPanel();
      await interaction.channel.send(panel);
      await interaction.reply({
        content: '✅ تم إرسال لوحة التذاكر بنجاح',
        ephemeral: true
      });
      break;
    }

    case 'ticket-stats': {
      const stats = storage.getStats();
      const embed = new EmbedBuilder()
        .setColor(config.COLORS.INFO)
        .setTitle(`${config.EMOJIS.TICKET} إحصائيات نظام التذاكر`)
        .setDescription(`
          \`\`\`
          ╔══════════════════════════╗
          ║         الإحصائيات          ║
          ╚══════════════════════════╝
          \`\`\`

          ### 📊 الأرقام والإحصائيات
          > 🎫 إجمالي التذاكر: ${stats.totalTickets}
          > 🔒 التذاكر المغلقة: ${stats.closedTickets}
          > ⭐ متوسط التقييم: ${stats.averageRating.toFixed(1)}
          > 📝 عدد التقييمات: ${stats.ratingCount}
        `);

      await interaction.reply({ embeds: [embed] });
      break;
    }
  }
});

// Support menu handler
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu() || interaction.customId !== 'select_support') return;

  const value = interaction.values[0];
  const userId = interaction.user.id;

  // Check user tickets
  const userTickets = storage.getUserTickets(userId);
  if (userTickets.length >= config.LIMITS.MAX_TICKETS_PER_USER) {
    return interaction.reply({
      content: `❌ لديك ${userTickets.length} تذاكر مفتوحة. الحد الأقصى هو ${config.LIMITS.MAX_TICKETS_PER_USER} تذاكر`,
      ephemeral: true
    });
  }

  // Show game support form
  if (value === 'games_support') {
    const modal = new ModalBuilder()
      .setCustomId('game_support_modal')
      .setTitle('🎮 دعم الألعاب');

    const gameInput = new TextInputBuilder()
      .setCustomId('game')
      .setLabel('ما هي اللعبة؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const userInput = new TextInputBuilder()
      .setCustomId('reported_user')
      .setLabel('من هو الشخص الذي تواجه مشكلة معه؟')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const issueInput = new TextInputBuilder()
      .setCustomId('problem')
      .setLabel('ما هي المشكلة؟')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    const needOwnerInput = new TextInputBuilder()
      .setCustomId('need_owner')
      .setLabel('هل تحتاج تدخل صاحب السيرفر؟ (نعم / لا)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(gameInput),
      new ActionRowBuilder().addComponents(userInput),
      new ActionRowBuilder().addComponents(issueInput),
      new ActionRowBuilder().addComponents(needOwnerInput)
    );

    await interaction.showModal(modal);
    return;
  }

  // Create ticket channel
  const channelName = `${config.EMOJIS.TICKET}・${value}-${interaction.user.username}`;
  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: config.CATEGORY_ID,
    permissionOverwrites: [
      { 
        id: interaction.guild.id, 
        deny: [PermissionsBitField.Flags.ViewChannel] 
      },
      { 
        id: interaction.user.id, 
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.AttachFiles,
          PermissionsBitField.Flags.EmbedLinks
        ]
      },
      { 
        id: config.ADMIN_ROLE_ID, 
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.AttachFiles,
          PermissionsBitField.Flags.EmbedLinks,
          PermissionsBitField.Flags.ManageMessages
        ]
      }
    ]
  });

  // Save ticket data
  const ticketData = {
    channelId: channel.id,
    userId: interaction.user.id,
    type: value,
    createdAt: Date.now(),
    status: 'open'
  };

  storage.setTicket(channel.id, ticketData);
  storage.incrementTotalTickets();

  // Send ticket embed
  const embed = EmbedManager.ticketEmbed(value, interaction.user, {
    ticketId: channel.id
  });

  const controls = EmbedManager.ticketControls();

  await channel.send({
    content: `${interaction.user} | <@&${config.ADMIN_ROLE_ID}>`,
    embeds: [embed],
    components: [controls]
  });

  await interaction.reply({
    content: `✅ تم فتح تذكرتك في ${channel}`,
    ephemeral: true
  });
});

// Game support modal handler
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit() || interaction.customId !== 'game_support_modal') return;

  const game = interaction.fields.getTextInputValue('game');
  const reported = interaction.fields.getTextInputValue('reported_user');
  const problem = interaction.fields.getTextInputValue('problem');
  const needOwner = interaction.fields.getTextInputValue('need_owner');

  // Create ticket channel
  const channelName = `${config.EMOJIS.GAMES}・game-${interaction.user.username}`;
  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: config.CATEGORY_ID,
    permissionOverwrites: [
      { 
        id: interaction.guild.id, 
        deny: [PermissionsBitField.Flags.ViewChannel] 
      },
      { 
        id: interaction.user.id, 
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.AttachFiles,
          PermissionsBitField.Flags.EmbedLinks
        ]
      },
      { 
        id: config.ADMIN_ROLE_ID, 
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.AttachFiles,
          PermissionsBitField.Flags.EmbedLinks,
          PermissionsBitField.Flags.ManageMessages
        ]
      }
    ]
  });

  // Save ticket data
  const ticketData = {
    channelId: channel.id,
    userId: interaction.user.id,
    type: 'games_support',
    game,
    reported,
    problem,
    needOwner: needOwner.toLowerCase() === 'نعم',
    createdAt: Date.now(),
    status: 'open'
  };

  storage.setTicket(channel.id, ticketData);
  storage.incrementTotalTickets();

  // Send ticket embed
  const embed = EmbedManager.ticketEmbed('games_support', interaction.user, ticketData);
  const controls = EmbedManager.ticketControls();

  const mentions = needOwner.toLowerCase() === 'نعم' 
    ? `${interaction.user} | <@&${config.ADMIN_ROLE_ID}> | <@${config.OWNER_ID}>`
    : `${interaction.user} | <@&${config.ADMIN_ROLE_ID}>`;

  await channel.send({
    content: mentions,
    embeds: [embed],
    components: [controls]
  });

  await interaction.reply({
    content: `✅ تم فتح تذكرة دعم الألعاب في ${channel}`,
    ephemeral: true
  });
});

// Button handlers
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  const { customId } = interaction;
  const ticket = storage.getTicket(interaction.channel.id);

  switch (customId) {
    case 'claim_ticket': {
      if (!interaction.member.roles.cache.has(config.ADMIN_ROLE_ID)) {
        return interaction.reply({
          content: '❌ عذراً، هذا الزر للإدارة فقط',
          ephemeral: true
        });
      }

      if (ticket?.claimed) {
        return interaction.reply({
          content: `❌ هذه التذكرة مستلمة بالفعل من قبل <@${ticket.claimedBy}>`,
          ephemeral: true
        });
      }

      // Update ticket data
      ticket.claimed = true;
      ticket.claimedBy = interaction.user.id;
      ticket.claimedAt = Date.now();
      storage.setTicket(interaction.channel.id, ticket);

      // Update message
      const message = (await interaction.channel.messages.fetch()).first();
      const oldEmbed = message.embeds[0];
      
      // Create new embed with the same data plus the claim info
      const newEmbed = EmbedBuilder.from(oldEmbed)
        .addFields({
          name: '👤 حالة التذكرة',
          value: `تم استلام التذكرة بواسطة ${interaction.user}`
        });

      const controls = EmbedManager.ticketControls(true, interaction.user.id);

      await message.edit({
        embeds: [newEmbed],
        components: [controls]
      });

      await interaction.reply(`✅ تم استلام التذكرة بواسطة ${interaction.user}`);
      break;
    }

    case 'close_ticket': {
      const confirmRow = EmbedManager.closeConfirmation();
      await interaction.reply({
        content: 'هل أنت متأكد أنك تريد إغلاق التذكرة؟',
        components: [confirmRow],
        ephemeral: true
      });
      break;
    }

    case 'confirm_close': {
      await interaction.update({
        content: '🚨 سيتم إغلاق التذكرة خلال 5 ثوان...',
        components: []
      });

      // Create transcript
      const messages = await interaction.channel.messages.fetch();
      const transcript = messages.reverse().map(m => {
        const time = new Date(m.createdTimestamp).toLocaleString('ar-SA');
        return `[${time}] ${m.author.tag}: ${m.content}`;
      }).join('\n');

      const transcriptFile = new AttachmentBuilder(
        Buffer.from(transcript, 'utf8'),
        { name: `transcript-${interaction.channel.name}.txt` }
      );

      // Calculate duration
      const duration = Date.now() - ticket.createdAt;
      const hours = Math.floor(duration / (1000 * 60 * 60));
      const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));

      const transcriptEmbed = EmbedManager.transcriptEmbed({
        channelName: interaction.channel.name,
        creator: `<@${ticket.userId}>`,
        claimer: ticket.claimed ? `<@${ticket.claimedBy}>` : null,
        rating: ticket.rating,
        createdAt: new Date(ticket.createdAt).toLocaleString('ar-SA'),
        closedAt: new Date().toLocaleString('ar-SA'),
        duration: `${hours}h ${minutes}m`
      });

      const transcriptChannel = await client.channels.fetch(config.TRANSCRIPT_CHANNEL_ID);
      await transcriptChannel.send({
        embeds: [transcriptEmbed],
        files: [transcriptFile]
      });

      // Delete channel
      setTimeout(() => {
        storage.deleteTicket(interaction.channel.id);
        interaction.channel.delete().catch(console.error);
      }, 5000);
      break;
    }

    case 'cancel_close': {
      await interaction.update({
        content: '❌ تم إلغاء عملية إغلاق التذكرة',
        components: []
      });
      break;
    }

    case 'rate_support': {
      if (interaction.user.id !== ticket.userId) {
        return interaction.reply({
          content: '❌ عذراً، فقط صاحب التذكرة يمكنه التقييم',
          ephemeral: true
        });
      }

      const embed = EmbedManager.ratingEmbed(`<@${ticket.claimedBy}>`);
      const controls = EmbedManager.ratingControls();

      await interaction.reply({
        embeds: [embed],
        components: controls,
        ephemeral: true
      });
      break;
    }

    default: {
      if (customId.startsWith('rate_')) {
        const rating = parseInt(customId.split('_')[1]);
        
        // Save rating
        ticket.rating = rating;
        storage.setTicket(interaction.channel.id, ticket);

        // Add rating to storage
        storage.addRating(interaction.channel.id, {
          rating,
          staffId: ticket.claimedBy,
          userId: ticket.userId,
          ticketType: ticket.type,
          staffTag: interaction.guild.members.cache.get(ticket.claimedBy)?.user.tag || 'Unknown Staff',
          userTag: interaction.user.tag
        });

        // Get staff stats
        const staffStats = storage.getStaffRatings(ticket.claimedBy);
        
        const ratingEmojis = {
          5: '🌟',
          4: '⭐',
          3: '💫',
          2: '✨',
          1: '💭'
        };

        const ratingLabels = {
          5: 'ممتاز',
          4: 'جيد جداً',
          3: 'جيد',
          2: 'مقبول',
          1: 'ضعيف'
        };

        // Send rating feedback to rating channel
        const ratingChannel = client.channels.cache.get(config.RATING_CHANNEL_ID);
        if (ratingChannel) {
          const feedbackEmbed = new EmbedBuilder()
            .setColor(config.COLORS.PRIMARY)
            .setTitle(`${ratingEmojis[rating]} تقييم جديد للدعم الفني`)
            .setDescription(`
              \`\`\`
              ╔═══════════════════════════════════════════╗
              ║                تقييم الخدمة               ║
              ╚═══════════════════════════════════════════╝
              \`\`\`

              ### ${config.EMOJIS.SUPPORT} معلومات التقييم
              \`\`\`yaml
              التقييم: ${ratingEmojis[rating]} ${ratingLabels[rating]} (${rating}/5)
              الموظف: ${interaction.guild.members.cache.get(ticket.claimedBy)?.user.tag || 'Unknown Staff'}
              العضو: ${interaction.user.tag}
              نوع التذكرة: ${ticket.type}
              رقم التذكرة: #${interaction.channel.id}
              التاريخ: ${new Date().toLocaleString('ar-SA')}
              \`\`\`

              ### 📊 إحصائيات الموظف
              > 📈 متوسط التقييم: ${staffStats.average.toFixed(1)}/5
              > 📝 عدد التقييمات: ${staffStats.count}
              > ⭐ مجموع النجوم: ${staffStats.totalStars}

              ### 📋 آخر 5 تقييمات للموظف
              ${staffStats.ratings
                .slice(-5)
                .map(r => `> ${ratingEmojis[r.rating]} ${r.userTag} - ${new Date(r.timestamp).toLocaleString('ar-SA')}`)
                .join('\n')}

              ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            `)
            .setFooter({ 
              text: `${config.serverName} - نظام تقييم الدعم الفني`, 
              iconURL: config.serverIcon 
            })
            .setTimestamp();

          await ratingChannel.send({ embeds: [feedbackEmbed] });
        }

        await interaction.update({
          content: `${ratingEmojis[rating]} شكراً لتقييمك! تم تقييم الخدمة: **${ratingLabels[rating]}** (${rating} ${rating > 1 ? 'نجوم' : 'نجمة'})`,
          embeds: [],
          components: []
        });
      }
      break;
    }
  }
});

// Add select menu handler for ratings
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu() || interaction.customId !== 'rate_select') return;

  const ticket = storage.getTicket(interaction.channel.id);
  if (!ticket) {
    return interaction.reply({
      content: '❌ عذراً، لم يتم العثور على معلومات التذكرة',
      ephemeral: true
    });
  }

  if (interaction.user.id !== ticket.userId) {
    return interaction.reply({
      content: '❌ عذراً، فقط صاحب التذكرة يمكنه التقييم',
      ephemeral: true
    });
  }

  if (!ticket.claimedBy) {
    return interaction.reply({
      content: '❌ عذراً، لا يمكن تقييم تذكرة لم يتم استلامها بعد',
      ephemeral: true
    });
  }

  const rating = parseInt(interaction.values[0].split('_')[1]);
  if (isNaN(rating) || rating < 1 || rating > 5) {
    return interaction.reply({
      content: '❌ عذراً، حدث خطأ في التقييم. الرجاء المحاولة مرة أخرى',
      ephemeral: true
    });
  }

  try {
    // Save rating to ticket
    ticket.rating = rating;
    storage.setTicket(interaction.channel.id, ticket);

    // Add rating to storage
    storage.addRating(interaction.channel.id, {
      rating,
      staffId: ticket.claimedBy,
      userId: ticket.userId,
      ticketType: ticket.type,
      staffTag: interaction.guild.members.cache.get(ticket.claimedBy)?.user.tag || 'Unknown Staff',
      userTag: interaction.user.tag
    });

    // Get staff stats
    const staffStats = storage.getStaffRatings(ticket.claimedBy);
    
    const ratingEmojis = {
      5: '🌟',
      4: '⭐',
      3: '💫',
      2: '✨',
      1: '💭'
    };

    const ratingLabels = {
      5: 'ممتاز',
      4: 'جيد جداً',
      3: 'جيد',
      2: 'مقبول',
      1: 'ضعيف'
    };

    // Send rating feedback to rating channel
    const ratingChannel = client.channels.cache.get(config.RATING_CHANNEL_ID);
    if (ratingChannel) {
      const feedbackEmbed = new EmbedBuilder()
        .setColor(config.COLORS.PRIMARY)
        .setTitle(`${ratingEmojis[rating]} تقييم جديد للدعم الفني`)
        .setDescription(`
          \`\`\`
          ╔═══════════════════════════════════════════╗
          ║                تقييم الخدمة               ║
          ╚═══════════════════════════════════════════╝
          \`\`\`

          ### ${config.EMOJIS.SUPPORT} معلومات التقييم
          \`\`\`yaml
          التقييم: ${ratingEmojis[rating]} ${ratingLabels[rating]} (${rating}/5)
          الموظف: ${interaction.guild.members.cache.get(ticket.claimedBy)?.user.tag || 'Unknown Staff'}
          العضو: ${interaction.user.tag}
          نوع التذكرة: ${ticket.type}
          رقم التذكرة: #${interaction.channel.id}
          التاريخ: ${new Date().toLocaleString('ar-SA')}
          \`\`\`

          ### 📊 إحصائيات الموظف
          > 📈 متوسط التقييم: ${staffStats.average.toFixed(1)}/5
          > 📝 عدد التقييمات: ${staffStats.count}
          > ⭐ مجموع النجوم: ${staffStats.totalStars}

          ### 📋 آخر 5 تقييمات للموظف
          ${staffStats.ratings
            .slice(-5)
            .map(r => `> ${ratingEmojis[r.rating]} ${r.userTag} - ${new Date(r.timestamp).toLocaleString('ar-SA')}`)
            .join('\n')}

          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        `)
        .setFooter({ 
          text: `${config.serverName} - نظام تقييم الدعم الفني`, 
          iconURL: config.serverIcon 
        })
        .setTimestamp();

      await ratingChannel.send({ embeds: [feedbackEmbed] });
    }

    await interaction.update({
      content: `${ratingEmojis[rating]} شكراً لتقييمك! تم تقييم الخدمة: **${ratingLabels[rating]}** (${rating} ${rating > 1 ? 'نجوم' : 'نجمة'})`,
      embeds: [],
      components: []
    });

  } catch (error) {
    console.error('Error handling rating:', error);
    await interaction.reply({
      content: '❌ عذراً، حدث خطأ أثناء حفظ التقييم. الرجاء المحاولة مرة أخرى',
      ephemeral: true
    });
  }
});

// Login
client.login(config.TOKEN);
