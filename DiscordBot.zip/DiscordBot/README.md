# Discord Ticket System Bot

A comprehensive Discord ticket system bot with admin controls, rating system, and transcript generation. Built with Discord.js v14 and featuring a modular architecture for easy maintenance and scaling.

## Features

### 🎫 Ticket Management
- **Multiple Support Categories**: Discord support, Games support, and Issue reporting
- **Interactive Ticket Creation**: Modal forms for detailed information collection
- **Permission-Based Access**: Proper role and permission management
- **Anti-Spam Protection**: Ticket limits per user and cooldown systems

### 👑 Admin Controls
- **Ticket Claiming System**: Staff can claim tickets for organized support
- **Slash Commands**: Easy-to-use admin commands for panel management
- **Statistics Dashboard**: Comprehensive ticket and rating statistics
- **Health Check System**: Monitor bot and system status

### ⭐ Rating System
- **User Feedback**: 5-star rating system for support quality
- **Rating Analytics**: Track average ratings and service quality
- **Staff Performance**: Individual staff member rating tracking

### 📋 Transcript & Archiving
- **Automatic Transcripts**: Generate conversation logs when tickets close
- **Archive Channel**: Organized storage of closed tickets
- **Backup System**: Automatic data backups with rotation

### 🛡️ Security & Reliability
- **Input Validation**: Comprehensive validation and sanitization
- **Error Handling**: Robust error handling with detailed logging
- **Rate Limiting**: Protection against spam and abuse
- **Data Persistence**: JSON-based storage with backup functionality

## Installation

### Prerequisites
- Node.js 16.9.0 or higher
- A Discord Bot Token
- A Discord Server with appropriate permissions

### Setup Steps

1. **Clone or Download the Files**
   ```bash
   # Create a new directory for your bot
   mkdir discord-ticket-bot
   cd discord-ticket-bot
   
   # Copy all the provided files to this directory
   ```

2. **Install Dependencies**
   ```bash
   npm install discord.js dotenv
   ```

3. **Environment Configuration**
   ```bash
   # Copy the example environment file
   cp .env.example .env
   
   # Edit the .env file with your configuration
   nano .env
   ```

4. **Configure Your Bot**
   Edit the `.env` file with your Discord server information:
   ```env
   DISCORD_TOKEN=your_bot_token_here
   GUILD_ID=your_guild_id_here
   CATEGORY_ID=your_category_id_here
   ADMIN_ROLE_ID=your_admin_role_id_here
   OWNER_ID=your_owner_id_here
   RATING_CHANNEL_ID=your_rating_channel_id_here
   TRANSCRIPT_CHANNEL_ID=your_transcript_channel_id_here
   ```

5. **Start the Bot**
   ```bash
   node index.js
   ```

## Configuration

### Required Discord Setup

1. **Create Bot Application**
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Create a new application
   - Go to the "Bot" section
   - Create a bot and copy the token

2. **Bot Permissions**
   Your bot needs the following permissions:
   - `Send Messages`
   - `Use Slash Commands`
   - `Manage Channels`
   - `Manage Messages`
   - `Embed Links`
   - `Attach Files`
   - `Read Message History`
   - `Use External Emojis`

3. **Server Setup**
   - Create a category for tickets
   - Create channels for ratings and transcripts
   - Create an admin role for staff
   - Note down all the IDs for configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DISCORD_TOKEN` | Your bot's token | ✅ |
| `GUILD_ID` | Your Discord server ID | ✅ |
| `CATEGORY_ID` | Category where tickets will be created | ✅ |
| `ADMIN_ROLE_ID` | Role that can manage tickets | ✅ |
| `OWNER_ID` | Server owner's user ID | ✅ |
| `RATING_CHANNEL_ID` | Channel for rating notifications | ✅ |
| `TRANSCRIPT_CHANNEL_ID` | Channel for ticket archives | ✅ |
| `MAX_TICKETS_PER_USER` | Maximum tickets per user | ❌ (default: 2) |
| `WORKING_HOURS_START` | Support start time | ❌ (default: 12:00) |
| `WORKING_HOURS_END` | Support end time | ❌ (default: 01:00) |
| `SERVER_NAME` | Your server's name | ❌ |
| `SERVER_ICON` | Your server's icon URL | ❌ |

## Usage

### Admin Commands

- `/send-ticket-panel` - Sends the ticket creation panel
- `/ticket-stats` - Shows comprehensive ticket statistics
- `/health-check` - Checks bot and system health

### Ticket Flow

1. **User Creates Ticket**
   - Select support type from dropdown menu
   - Fill out modal form (for game support)
   - Ticket channel is created automatically

2. **Staff Management**
   - Staff can claim tickets using the "Claim" button
   - Use "Close" button to initiate ticket closure
   - Confirm closure to generate transcript and archive

3. **Rating System**
   - Users receive rating prompt via DM after ticket closure
   - Ratings are saved and contribute to statistics
   - Staff performance is tracked automatically

## File Structure

