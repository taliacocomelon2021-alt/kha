const { Client, GatewayIntentBits, Partials } = require('discord.js');
const config = require('./config/config');
const logger = require('./utils/logger');
const storage = require('./utils/storage');

// Import handlers
const commandHandler = require('./handlers/commands');
const eventHandler = require('./handlers/interactions');

// Create client instance
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds
  ]
});

// Global error handlers
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

// Initialize storage
storage.init();

// Load event handlers
require('./events/ready')(client);
require('./events/interactionCreate')(client);

// Graceful shutdown
process.on('SIGINT', () => {
  logger.info('Received SIGINT, shutting down gracefully...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('Received SIGTERM, shutting down gracefully...');
  client.destroy();
  process.exit(0);
});

// Start the bot
client.login(config.DISCORD_TOKEN).catch(error => {
  logger.error('Failed to login:', error);
  console.error('Login error details:', error);
  if (error.code) {
    console.error('Error code:', error.code);
  }
  if (error.message) {
    console.error('Error message:', error.message);
  }
  process.exit(1);
});

module.exports = client;
