# Discord Ticket System Bot - Complete Setup Guide

This guide will walk you through setting up the Discord Ticket System Bot step by step, from creating the Discord application to running the bot on your server.

## Table of Contents
1. [Discord Bot Setup](#discord-bot-setup)
2. [Server Preparation](#server-preparation)
3. [Bot Installation](#bot-installation)
4. [Configuration](#configuration)
5. [Testing](#testing)
6. [Deployment](#deployment)
7. [Troubleshooting](#troubleshooting)

## Discord Bot Setup

### Step 1: Create Discord Application

1. **Go to Discord Developer Portal**
   - Visit [https://discord.com/developers/applications](https://discord.com/developers/applications)
   - Log in with your Discord account

2. **Create New Application**
   - Click "New Application" button
   - Enter a name for your bot (e.g., "Ticket System Bot")
   - Click "Create"

3. **Configure General Information**
   - Add a description for your bot
   - Upload an icon (optional)
   - Note down the Application ID for later

### Step 2: Create Bot User

1. **Navigate to Bot Section**
   - Click "Bot" in the left sidebar
   - Click "Add Bot" button
   - Confirm by clicking "Yes, do it!"

2. **Configure Bot Settings**
   - Set a username for your bot
   - Upload an avatar (optional)
   - **Important**: Copy the bot token and save it securely
   - Enable "Message Content Intent" under "Privileged Gateway Intents"

3. **Bot Permissions**
   - Scroll down to "Bot Permissions"
   - Select the following permissions:
     - `Send Messages`
     - `Use Slash Commands`
     - `Manage Channels`
     - `Manage Messages`
     - `Embed Links`
     - `Attach Files`
     - `Read Message History`
     - `Use External Emojis`
     - `View Channel`

### Step 3: Generate Invite Link

1. **OAuth2 URL Generator**
   - Click "OAuth2" > "URL Generator" in sidebar
   - Under "Scopes", select:
     - `bot`
     - `applications.commands`
   - Under "Bot Permissions", select the same permissions as above
   - Copy the generated URL

2. **Invite Bot to Server**
   - Open the generated URL in browser
   - Select your Discord server
   - Click "Authorize"
   - Complete the captcha if prompted

## Server Preparation

### Step 1: Get Discord IDs

**Enable Developer Mode:**
1. Open Discord settings (gear icon)
2. Go to "Advanced" section
3. Enable "Developer Mode"

**Get Required IDs:**
1. **Guild ID**: Right-click your server name → "Copy Server ID"
2. **Category ID**: Create or right-click existing category → "Copy Channel ID"
3. **Channel IDs**: Right-click channels → "Copy Channel ID"
4. **Role ID**: Server Settings → Roles → Right-click admin role → "Copy Role ID"
5. **User ID**: Right-click your username → "Copy User ID"

### Step 2: Create Required Channels and Roles

1. **Create Ticket Category**
   - Right-click in channel list
   - Select "Create Category"
   - Name it "Tickets" or similar
   - Copy the category ID

2. **Create Support Channels**
   - Create a channel for ratings (e.g., "ratings")
   - Create a channel for transcripts (e.g., "ticket-archives")
   - Copy both channel IDs

3. **Create Admin Role**
   - Go to Server Settings → Roles
   - Create a new role (e.g., "Support Staff")
   - Give appropriate permissions
   - Copy the role ID

4. **Set Permissions**
   - Ensure bot has access to all required channels
   - Test by mentioning the bot in each channel

## Bot Installation

### Step 1: Prepare Environment

1. **Install Node.js**
   - Download from [https://nodejs.org](https://nodejs.org)
   - Install version 16.9.0 or higher
   - Verify installation: `node --version`

2. **Create Project Directory**
   ```bash
   mkdir discord-ticket-bot
   cd discord-ticket-bot
   ```

3. **Download Bot Files**
   - Copy all the provided bot files to your project directory
   - Ensure the directory structure matches the documentation

### Step 2: Install Dependencies

```bash
# Install required packages
npm install discord.js dotenv

# Optional: Install PM2 for production deployment
npm install -g pm2
